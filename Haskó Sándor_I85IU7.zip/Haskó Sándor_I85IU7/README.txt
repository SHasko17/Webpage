Üdvözlöm Tanár Úr!

A weboldalam közel sincs tökéletes, de a legtöbb funkciót amit megadott megpróbáltam megvalósítani.
A választott témám az autókról szólt.
Nálam csak admin felhasználó tud szerkeszteni, törölni illetve feltölteni adatokat felvinni, átlag fekhasználó csak megnézheti az oldal tartalmát(ami jelenleg üresen áll, mert kitöröltem mindent, hogy le tudja tesztelni).
A megadott autók adatát le tudja tölteni egy csv fájlban, azonban nem sikerült a feltöltést megvalósítani, mert nagy akadálynak bizonyult számomra.
Profil fülbe alap adatokat ír le a felhasználóról, emailt, nevet és felhasználónevet.
A profil fülbe tud email módosítani illetve jelszavat változtatni valamint profil képet feltölteni/módosítani magának.

Sajnos az adatbázis része nem volt nagy erősségem, és szerintem nem biztos, hogy minden kritériumnak megfelel ha megfelel valamelyiknek.
Azt hiszem ez minden.

Lehetne sokkal jobb is az oldalam, de sajnos munka mellett és a vizsgákra/zh-kra való felkészülés sok időt rabolt el tőlem, azonban ha így is elégtelen lenne akkor azt is vállalom, max majd legközelebb jobban sikerül.
Köszönöm az előadásait és munkáját, sokat tudtam fejlődni a nehézségekkel együtt is.